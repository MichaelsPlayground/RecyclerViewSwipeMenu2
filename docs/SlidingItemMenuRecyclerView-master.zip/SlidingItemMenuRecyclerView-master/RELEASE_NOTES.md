# Release Notes

### 2.0 (2021-03-02)
* No notes provided.

### 1.0.4 (2019-11-21)
* No notes provided.

### 1.0.3 (2019-08-27)
* Library
    * Update default recycler item selector.
    * Item menu can now be opened programmatically.

### 1.0.2 (2019-02-27)
* Library
    * Fix a bug on platforms prior to `Nougat`.

### 1.0.1 (2018-12-15)
* Library
    * Touch event optimizations.

### 1.0 (2018-11-24)
* No notes provided.